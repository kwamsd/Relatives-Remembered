<template>
    <main>
        <section class="left-section">
            <div class="photo-frame">
                <img src="../assets/images/phoyo-pp.jpg" alt="Portrait of Lilia Sanchez" />
            </div>
            <div class="identity-card">
                <p><span style="font-weight: 300; font-size: 16px;">Lilia</span> <strong>SANCHEZ</strong></p>
                <p>1965 — 2020</p>
            </div>
            <div class="details-box">
                <p><strong>Full Name:</strong> Lilia Maria Sanchez</p>
                <p><strong>Profession:</strong> Schoolteacher</p>
                <p><strong>Birthplace:</strong> Oaxaca, Mexico</p>
                <p><strong>Known For:</strong> Her passion for literature and helping underprivileged children</p>
                <p><strong>Family:</strong> Survived by her two children and husband</p>
                <p><strong>Legacy:</strong> Established a reading program in her community</p>
            </div>
        </section>

        <section class="right-section">
            <div class="description-box">
                <p>Lilia Sanchez was a woman of strength, kindness, and unwavering dedication to her students. Her
                    influence reached far beyond the classroom, touching the hearts of everyone she met.</p>
            </div>
            <div class="anecdotes-box">
                <p><strong>From Maria G.:</strong> "She helped me believe in myself when no one else did. Her classroom
                    was a safe haven."</p>
                <p><strong>From Diego R.:</strong> "I'll never forget the way she made poetry come alive. Every lesson
                    felt like magic."</p>
                <p><strong>From Elena V.:</strong> "She gave me my first book. That small gesture changed everything for
                    me."</p>
                <p><strong>From Tomás F.:</strong> "Even outside of school, she was there. She showed up when others
                    didn’t."</p>
                <p><strong>From Maria G.:</strong> "She helped me believe in myself when no one else did. Her classroom
                    was a safe haven."</p>
                <p><strong>From Diego R.:</strong> "I'll never forget the way she made poetry come alive. Every lesson
                    felt like magic."</p>
                <p><strong>From Elena V.:</strong> "She gave me my first book. That small gesture changed everything for
                    me."</p>
                <p><strong>From Tomás F.:</strong> "Even outside of school, she was there. She showed up when others
                    didn’t."</p>
            </div>
        </section>
    </main>
</template>

<script setup>
import '../assets/css/dead.css'
</script>