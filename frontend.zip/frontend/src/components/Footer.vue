<template>
  <footer>
    &copy; 2025 Relatives Remembered. All rights reserved. | <router-link to="/about/contact">Contact</router-link> | Privacy Policy | Terms
  </footer>
</template>

<script setup>
import '../assets/css/components/Footer.css'
</script>
